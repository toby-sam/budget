// ===============================
// budget.js – STABLE FINAL VERSION
// ===============================

let stateB = State.load();

// Elements
const elsB = {
    summaryIncome: document.getElementById('summaryIncome'),
    summaryHouse: document.getElementById('summaryHouse'),
    summarySamal: document.getElementById('summarySamal'),
    summaryTotalSpend: document.getElementById('summaryTotalSpend'),
    summaryProfitLoss: document.getElementById('summaryProfitLoss'),
    summaryTotalBudget: document.getElementById('summaryTotalBudget'),
    summaryLedger: document.getElementById('summaryLedger'),
    summaryPhilippines: document.getElementById('summaryPhilippines'),

    newCategoryName: document.getElementById('newCategoryName'),
    newCategoryMonthly: document.getElementById('newCategoryMonthly'),
    addCategoryBtn: document.getElementById('addCategoryBtn'),

    catBody: document.querySelector('#categoriesTable tbody'),
    saveBackupBtn: document.getElementById('saveBackupBtn'),
    loadBackupBtn: document.getElementById('loadBackupBtn'),
    loadBackupInput: document.getElementById('loadBackupInput'),
};


// ===============================
// Formatters
// ===============================
function formatAud(v) {
    if (isNaN(v)) v = 0;
    return "$" + Number(v).toFixed(2);
}

function formatPhp(v) {
    if (isNaN(v)) v = 0;
    return "₱" + Number(v).toLocaleString("en-PH", { minimumFractionDigits: 2 });
}


// ===============================
// AU Spend (ledger only)
// ===============================
function computeAuSpend() {
    return (stateB.ledger || []).reduce((sum, tx) => {
        const amt = Number(tx.amount) || 0;
        return sum + (amt > 0 ? amt : 0);
    }, 0);
}


// ===============================
// PH Spend (PHP)
// ===============================
function computePhSpendPhp() {
    return (stateB.philippines || []).reduce((sum, tx) => {
        const php = Number(tx.amountPhp) || 0;
        return sum + (php > 0 ? php : 0);
    }, 0);
}


// ===============================
// Convert PH Spend → AUD
// ===============================
function computePhSpendAud() {
    const rate = Number(stateB.phpAudRate) || 0;
    return computePhSpendPhp() * rate;
}


// ===============================
// PH Budget (PHP)
// ===============================
function computePhBudgetPhp() {
    return (stateB.phBudgetCategories || []).reduce((sum, c) => {
        return sum + (Number(c.budgetMonthly) || 0);
    }, 0);
}


// ===============================
// Main Summary Panel
// ===============================
function renderSummary() {
    const income = Number(stateB.income) || 0;

    const auSpend = computeAuSpend();
    const phSpendPhp = computePhSpendPhp();
    const phSpendAud = computePhSpendAud();
    const totalSpendAud = auSpend + phSpendAud;

    const profitLoss = income - totalSpendAud;

    const auBudget = (stateB.categories || []).reduce((sum, c) =>
        sum + (Number(c.budgetMonthly) || 0), 0
    );

    const phBudgetPhp = computePhBudgetPhp();
    const phNetPhp = phBudgetPhp - phSpendPhp;

    // Update UI
    elsB.summaryIncome.textContent = formatAud(income);
    elsB.summaryHouse.textContent = (stateB.housePct || 0) + "%";
    elsB.summarySamal.textContent = (stateB.samalPct || 0) + "%";

    elsB.summaryTotalSpend.textContent = formatAud(totalSpendAud);
    elsB.summaryProfitLoss.textContent = formatAud(profitLoss);

    elsB.summaryTotalBudget.textContent = formatAud(auBudget);
    elsB.summaryLedger.textContent = formatAud(auSpend);

    // PH Net Spend shown in PHP
    elsB.summaryPhilippines.textContent = formatPhp(phNetPhp);
}



// ===============================
// Categories Table Renderer
// ===============================
function renderCategories() {
    elsB.catBody.innerHTML = "";

    const actuals = (stateB.ledger || []).reduce((map, tx) => {
        if (!tx.category) return map;
        const amt = Number(tx.amount) || 0;
        if (amt > 0) {
            map[tx.category] = (map[tx.category] || 0) + amt;
        }
        return map;
    }, {});

    (stateB.categories || []).forEach((cat, idx) => {
        const tr = document.createElement("tr");

        // Name
        const tdName = document.createElement("td");
        tdName.textContent = cat.name;
        tr.appendChild(tdName);

        // Budget input
        const tdBudget = document.createElement("td");
        tdBudget.className = "amount";
        const input = document.createElement("input");
        input.type = "number";
        input.step = "0.01";
        input.value = cat.budgetMonthly || 0;
        input.oninput = () => {
            stateB.categories[idx].budgetMonthly = Number(input.value) || 0;
            State.save(stateB);
            renderSummary();
        };
        tdBudget.appendChild(input);
        tr.appendChild(tdBudget);

        // Actual
        const actual = actuals[cat.name] || 0;
        const tdActual = document.createElement("td");
        tdActual.className = "amount";
        tdActual.textContent = formatAud(actual);
        tr.appendChild(tdActual);

        // Difference
        const diff = (cat.budgetMonthly || 0) - actual;
        const tdDiff = document.createElement("td");
        tdDiff.className = "amount";
        tdDiff.textContent = formatAud(diff);
        tr.appendChild(tdDiff);

        // Status
        const tdStatus = document.createElement("td");
        tdStatus.textContent = diff >= 0 ? "Under Budget" : "Over Budget";
        tdStatus.className = diff >= 0 ? "status-positive" : "status-negative";
        tr.appendChild(tdStatus);

        elsB.catBody.appendChild(tr);
    });
}



// ===============================
// INIT — WITH SAFETY AUTOSAVE
// ===============================
function initBudget() {

    // SAFETY FIX: ensure categories always exist
    if (!stateB.categories || !Array.isArray(stateB.categories)) {
        stateB.categories = [];
    }

    // CRITICAL FIX: persist immediately so categories never vanish again
    State.save(stateB);

    renderSummary();
    renderCategories();

    // Add category
    elsB.addCategoryBtn.onclick = () => {
        const name = elsB.newCategoryName.value.trim();
        const monthly = Number(elsB.newCategoryMonthly.value) || 0;

        if (!name) return alert("Enter a category name.");
        if (stateB.categories.some(c => c.name.toLowerCase() === name.toLowerCase())) {
            return alert("Category already exists.");
        }

        stateB.categories.push({ name, budgetMonthly: monthly });
        State.save(stateB);

        elsB.newCategoryName.value = "";
        elsB.newCategoryMonthly.value = "";

        renderCategories();
        renderSummary();
    };

    // Load backup
    elsB.loadBackupBtn.onclick = () => elsB.loadBackupInput.click();
    elsB.loadBackupInput.onchange = e => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = ev => {
            try {
                stateB = JSON.parse(ev.target.result);
                State.save(stateB);
                renderSummary();
                renderCategories();
            } catch {
                alert("Invalid backup file.");
            }
        };
        reader.readAsText(file);
    };

    // Save backup
    elsB.saveBackupBtn.onclick = () => {
        const blob = new Blob([JSON.stringify(stateB, null, 2)], { type: "application/json" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "budget-backup.json";
        a.click();
    };
}

document.addEventListener('DOMContentLoaded', initBudget);
